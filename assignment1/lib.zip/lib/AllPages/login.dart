//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:assignment1/AllPages/homePage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MyLogin extends StatefulWidget {
  const MyLogin({Key? key}) : super(key: key);
 Future<FirebaseApp> _initializeFirebase() async {
    FirebaseApp firebaseApp= await Firebase.initializeApp();
    return firebaseApp;
  }
  @override
  // ignore: library_private_types_in_public_api
  _MyLoginState createState() => _MyLoginState();
 
  Widget build(BuildContext context) {
  return Scaffold(
    body: FutureBuilder(
      future: _initializeFirebase(),
      builder: (context, snapshot) {
        if(snapshot.connectionState==ConnectionState.done){
          return MyLogin();
        }
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    ),
  );
 }
}
class _MyLoginState extends State<MyLogin> {
  
  static Future<User?> loginUsingEmailPassword({required String email, required String password, required BuildContext}) async{
    FirebaseAuth auth = FirebaseAuth.instance;
    User? user;
    try{
      UserCredential userCredential = await auth.signInWithEmailAndPassword(email: email, password: password);
      user= userCredential.user;
    } on FirebaseAuthException catch (e){
      if (e.code == "user-not-found"){
        print("No User found for this email");
      }
    }
    return user;
  }
  //Initialize  Firebase app
  
//  Future<FirebaseApp> _InitializeFirebase() async {
//     FirebaseApp firebaseApp= await Firebase.initializeApp();
//     return firebaseApp;
//   }
 

  @override
  Widget build(BuildContext context) {
    TextEditingController _emailController= TextEditingController();
    TextEditingController _passwordController= TextEditingController();


    return Container(
      
      decoration: BoxDecoration(
        image: DecorationImage(
           image: AssetImage('assets/login.png'), fit: BoxFit.cover),
      ),
      child: Scaffold(
       
        backgroundColor: Colors.transparent,
        body: Stack(
        
    
          children: [
            Container(
              
              padding: EdgeInsets.only(left: 35, top: 130),
              child: Text(
                'Welcome To Our\n Login Page..',
                style: TextStyle(color: Color.fromARGB(255, 227, 218, 218), fontSize: 33),
              ),
            ),
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * 0.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 35, right: 35),
                      child: Column(
                        children: [
                          TextField(
                            controller:_emailController,
                            style: TextStyle(color: Color.fromARGB(255, 13, 13, 13)),
                            decoration: InputDecoration(
                                fillColor: Color.fromARGB(255, 236, 230, 230),
                                filled: true,
                                hintText: "Email",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          TextField(
                            controller:_passwordController,
                            style: TextStyle(),
                            obscureText: true,
                            decoration: InputDecoration(
                                fillColor: Colors.grey.shade100,
                                filled: true,
                                hintText: "Password",
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                )),
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Row(
                            
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Sign in',
                                style: TextStyle(
                                    fontSize: 27, fontWeight: FontWeight.w700, color: Colors.white),
                              ),
                              CircleAvatar(
                                radius: 30,
                                backgroundColor: Color(0xff4c505b),
                                child: IconButton(
                                    color: Colors.white,
                                    onPressed: () async {
                                      
                                     User? user= await loginUsingEmailPassword(email: _emailController.text, password:_passwordController.text, BuildContext: BuildContext);
                                      print (user);
                                      print('Hi');
                                      //if (true){
                                        if (user!=null){
                                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => MyhomePage()));
                                   // Navigator.pushNamed(context, 'homePage');
                                    }
                                    
                                      Navigator.pushNamed(context, 'homePage');
                                    
                                  
                                },
                                
                                    icon: Icon(
                                      Icons.arrow_forward,
                                    )),
                              )
                            ],
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TextButton(
                                onPressed: () {
                                  Navigator.pushNamed(context, 'register');
                                },
                                child: Text(
                                  'Sign Up',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                      decoration: TextDecoration.underline,
                                      color: Color.fromARGB(255, 242, 243, 245),
                                      fontSize: 28,
                                      fontFamily: 'RobotoMono'),
                                ),
                                style: ButtonStyle(),
                              ),
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
          ),
          ],
        ),
      ),
    );
    
  }
}
