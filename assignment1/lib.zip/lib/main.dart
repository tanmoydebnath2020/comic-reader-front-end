import 'package:flutter/material.dart';
import 'package:assignment1/AllPages/register.dart';
import 'package:assignment1/AllPages/login.dart';
import 'package:assignment1/AllPages/homePage.dart';
import 'package:assignment1/AllPages/free_chapter.dart';
import 'package:assignment1/AllPages/full_chapter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';



 Future<FirebaseApp> _initializeFirebase() async {
    FirebaseApp firebaseApp= await Firebase.initializeApp();
    return firebaseApp;
  }
  
void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyRegister(),
      routes: {
        'register': (context) => MyRegister(),
        'login': (context) => MyLogin(),
        'homePage': (context) => MyhomePage(),
        'free_chapter': (context) => FreeChapter(),
        'full_chapter': (context) => FullChapter()
      },
    ),
  );
}